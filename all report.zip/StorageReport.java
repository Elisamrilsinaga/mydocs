package id.co.maybank.mydocs.utils.report;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import id.co.maybank.mydocs.model.dto.StorageDto;

public class StorageReport {

	private List<StorageDto> storageList;
	private XSSFWorkbook workbook;
    private XSSFSheet sheet;
    
    public StorageReport(List <StorageDto> storageList) {
        this.storageList = storageList;
        workbook = new XSSFWorkbook();
    }
    
    private void writeHeader() {
        sheet = workbook.createSheet("Lemari dan Rak");
        
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        font.setFontHeight(11);
        
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setWrapText(true);
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
                
        XSSFRichTextString cellValue = new XSSFRichTextString();
        cellValue.append("Lemari & Rak", font);
        
        Row titleRow = sheet.createRow(0);
        Cell titlecell = titleRow.createCell(0);
        titlecell.setCellValue(cellValue);
        titlecell.setCellStyle(cellStyle);
        sheet.addMergedRegion(new CellRangeAddress(0,0,0,6));
        		
		Row row = sheet.createRow(1);
		CellStyle style = workbook.createCellStyle();    
        
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
		style.setWrapText(true);
        style.setFillForegroundColor(IndexedColors.GOLD.index);
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        
        createCell(row, 0, "No", style);
        createCell(row, 1, "Branch ID", style);
        createCell(row, 2, "Cabang", style);
        createCell(row, 3, "Nomor Lemari / Compactus", style);
        createCell(row, 4, "Jumlah Rak", style);
        createCell(row, 5, "Deskripsi", style);
        createCell(row, 6, "IsActive", style);
    }    
    
    private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
        sheet.autoSizeColumn(columnCount);
        Cell cell = row.createCell(columnCount);
        if (valueOfCell instanceof Integer) {
            cell.setCellValue((Integer) valueOfCell);
        } else if (valueOfCell instanceof Long) {
            cell.setCellValue((Long) valueOfCell);
        } else if (valueOfCell instanceof String) {
            cell.setCellValue((String) valueOfCell);
        }  else if (valueOfCell instanceof Double) {
            cell.setCellValue((Double) valueOfCell);
        }else {
            cell.setCellValue((Boolean) valueOfCell);
        }
        cell.setCellStyle(style);
    }
    
    private void write() {
        int rowCount = 2;
        int dataIdx = 1;
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setFontHeight(11);
        style.setFont(font);
        for (StorageDto record: storageList) {
            Row row = sheet.createRow(rowCount++);
            int columnCount = 0;
            String isActive;
            
            if(record.isActive() == true) {
            	isActive = "Aktif";
            }else {
            	isActive = "Non-aktif";
            }
            
            createCell(row, columnCount++, dataIdx, style);
            createCell(row, columnCount++, record.getBranch().getId(), style);
            createCell(row, columnCount++, record.getBranch().getName(), style);
            createCell(row, columnCount++, record.getId(), style);
            createCell(row, columnCount++, record.getRackamount(), style);
            createCell(row, columnCount++, record.getDescription(), style);
            createCell(row, columnCount++, isActive, style);
            
            dataIdx++;
        }
    }
    
    public void generateExcelFile(HttpServletResponse response) throws IOException {
        writeHeader();
        write();
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }
    
}



