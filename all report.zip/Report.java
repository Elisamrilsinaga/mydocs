package id.co.maybank.mydocs.utils.report;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.Units;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import id.co.maybank.mydocs.customexception.ReportException;
import id.co.maybank.mydocs.model.dto.DocumentFileReportDto;

public class Report {
	private Report() {
		throw new IllegalStateException("Utility class");
	}

	public static ByteArrayInputStream inKhazanah(List<DocumentFileReportDto> dataReport) {
		String[] headers = { "No", "Document ID", "CIF Number", "Nama Debitur", "Jenis Dokumen", "No Dokumen", "Notaris", "Wilayah BPN", "Cabang", "Lemari/Rak", "PIC BU", "PIC CDU" };
		String sheetTitle = "Report Dokumen di Khazanah";
		  
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet(sheetTitle);
			
			float widthExcel = 20f;
			int width256 = (int)Math.floor((widthExcel * Units.DEFAULT_CHARACTER_WIDTH + 5) / Units.DEFAULT_CHARACTER_WIDTH * 256);
			  
			XSSFFont fontBold = (XSSFFont) workbook.createFont();
			fontBold.setBold(true);
			
			CellStyle cellColorStyle = workbook.createCellStyle();
			cellColorStyle.setFillForegroundColor(IndexedColors.GOLD.index);
			cellColorStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			  
			CellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setWrapText(true);
			cellStyle.setAlignment(HorizontalAlignment.CENTER);
			  
			Row titleRow = sheet.createRow(0);
			Cell titlecell = titleRow.createCell(0);
			XSSFRichTextString cellValue = new XSSFRichTextString();
			cellValue.append("Report Dokumen di Khazanah", fontBold);
			  
			titlecell.setCellValue(cellValue);
			titlecell.setCellStyle(cellStyle);
			sheet.addMergedRegion(new CellRangeAddress(0,0,0,11));
			  
			// Header
			Row headerRow = sheet.createRow(1);
			for (int col = 0; col < headers.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(headers[col]);
				cell.setCellStyle(cellColorStyle);
				
				/**skip col No**/
				if (col == 0) {
					continue;
				}
				sheet.setColumnWidth(col, width256);
			}
			
			int rowIdx = 2;
			int dataIdx = 1;
			for (DocumentFileReportDto data : dataReport) {
				Row row = sheet.createRow(rowIdx);
			
			    row.createCell(0).setCellValue(dataIdx);
			    row.createCell(1).setCellValue(data.getId());
			    row.createCell(2).setCellValue(data.getCif());
			    row.createCell(3).setCellValue(data.getName());
			    row.createCell(4).setCellValue(data.getDoctype().getName());
			    row.createCell(5).setCellValue(data.getDocnumber());
			    row.createCell(6).setCellValue(data.getNotaris().getName());
			    row.createCell(7).setCellValue(data.getWilayah().getProvinsi());
			    row.createCell(8).setCellValue(data.getBranch().getName());
			    row.createCell(9).setCellValue(data.getStorageid().substring(4) +"/"+data.getRacknumber());
			    row.createCell(10).setCellValue(data.getUserbu().getName());
			    row.createCell(11).setCellValue(data.getUsercdu().getName());
			    
			    rowIdx++;
			    dataIdx++;
			}
			
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (IOException e) {
			throw new ReportException("fail to import data to Excel file: " + e.getMessage());
		}
	}
	
	public static ByteArrayInputStream fromNotaris(List<DocumentFileReportDto> dataReport) {
		String[] headers = { "No", "Document ID", "CIF Number", "Nama Debitur", "Jenis Dokumen", "No Dokumen", "Notaris", "Wilayah BPN", "Cabang", "Lemari/Rak", "PIC BU", "PIC CDU" };
		String sheetTitle = "Report Dokumen Diterima dari Notaris / Developer";
		  
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet(sheetTitle);
			
			float widthExcel = 20f;
			int width256 = (int)Math.floor((widthExcel * Units.DEFAULT_CHARACTER_WIDTH + 5) / Units.DEFAULT_CHARACTER_WIDTH * 256);
			  
			XSSFFont fontBold = (XSSFFont) workbook.createFont();
			fontBold.setBold(true);
			
			CellStyle cellColorStyle = workbook.createCellStyle();
			cellColorStyle.setFillForegroundColor(IndexedColors.GOLD.index);
			cellColorStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			  
			CellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setWrapText(true);
			cellStyle.setAlignment(HorizontalAlignment.CENTER);
			  
			Row titleRow = sheet.createRow(0);
			Cell titlecell = titleRow.createCell(0);
			XSSFRichTextString cellValue = new XSSFRichTextString();
			cellValue.append("Report Dokumen di Khazanah", fontBold);
			  
			titlecell.setCellValue(cellValue);
			titlecell.setCellStyle(cellStyle);
			sheet.addMergedRegion(new CellRangeAddress(0,0,0,11));
			  
			// Header
			Row headerRow = sheet.createRow(1);
			for (int col = 0; col < headers.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(headers[col]);
				cell.setCellStyle(cellColorStyle);
				
				/**skip col No**/
				if (col == 0) {
					continue;
				}
				sheet.setColumnWidth(col, width256);
			}
			
			int rowIdx = 2;
			int dataIdx = 1;
			for (DocumentFileReportDto data : dataReport) {
				Row row = sheet.createRow(rowIdx);
			
			    row.createCell(0).setCellValue(dataIdx);
			    row.createCell(1).setCellValue(data.getId());
			    row.createCell(2).setCellValue(data.getCif());
			    row.createCell(3).setCellValue(data.getName());
			    row.createCell(4).setCellValue(data.getDoctype().getName());
			    row.createCell(5).setCellValue(data.getDocnumber());
			    row.createCell(6).setCellValue(data.getNotaris().getName());
			    row.createCell(7).setCellValue(data.getWilayah().getProvinsi());
			    row.createCell(8).setCellValue(data.getBranch().getName());
			    row.createCell(9).setCellValue(data.getStorageid().substring(4) +"/"+data.getRacknumber());
			    row.createCell(10).setCellValue(data.getUserbu().getName());
			    row.createCell(11).setCellValue(data.getUsercdu().getName());
			    
			    rowIdx++;
			    dataIdx++;
			}
			
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (IOException e) {
			throw new ReportException("fail to import data to Excel file: " + e.getMessage());
		}
	}

}
