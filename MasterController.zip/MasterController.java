package id.co.maybank.mydocs.controller.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import id.co.maybank.mydocs.model.dto.AreaDto;
import id.co.maybank.mydocs.model.dto.BranchDto;
import id.co.maybank.mydocs.model.dto.DocumentTypeDto;
import id.co.maybank.mydocs.model.dto.KurirDto;
import id.co.maybank.mydocs.model.dto.NotarisDto;
import id.co.maybank.mydocs.model.dto.PinjamanTypeDto;
import id.co.maybank.mydocs.model.dto.RegionDto;
import id.co.maybank.mydocs.model.dto.SegmenDto;
import id.co.maybank.mydocs.model.dto.StorageDto;
import id.co.maybank.mydocs.model.dto.WilayahDto;
import id.co.maybank.mydocs.service.IAreaService;
import id.co.maybank.mydocs.service.IBranchService;
import id.co.maybank.mydocs.service.IDocumentTypeService;
import id.co.maybank.mydocs.service.IKurirService;
import id.co.maybank.mydocs.service.INotarisService;
import id.co.maybank.mydocs.service.IPinjamanTypeService;
import id.co.maybank.mydocs.service.IRegionService;
import id.co.maybank.mydocs.service.ISegmenService;
import id.co.maybank.mydocs.service.IStorageService;
import id.co.maybank.mydocs.service.IWilayahService;
import id.co.maybank.mydocs.utils.report.AreaReport;
import id.co.maybank.mydocs.utils.report.BranchReport;
import id.co.maybank.mydocs.utils.report.JenisDokumenReport;
import id.co.maybank.mydocs.utils.report.JenisPinjamanReport;
import id.co.maybank.mydocs.utils.report.KurirReport;
import id.co.maybank.mydocs.utils.report.NotarisReport;
import id.co.maybank.mydocs.utils.report.RegionReport;
import id.co.maybank.mydocs.utils.report.SegmenReport;
import id.co.maybank.mydocs.utils.report.StorageReport;
import id.co.maybank.mydocs.utils.report.WilayahReport;

@Controller
@RequestMapping("/master")
public class MasterController {

	@Autowired
	private IDocumentTypeService documentTypeService;
	@Autowired
	private IPinjamanTypeService pinjamanTypeService;
	@Autowired
	private ISegmenService segmenService;
	@Autowired
	private IWilayahService wilayahService;
	@Autowired
	private INotarisService notarisService;
	@Autowired
	private IKurirService kurirService;
	@Autowired
	private IRegionService regionService;
	@Autowired
	private IAreaService areaService;
	@Autowired
	private IBranchService branchService;
	@Autowired
	private IStorageService storageService;
	
	@GetMapping("/report")
	public String masterDocument(Model model) {
		return "pages/master/view";
	}
	
    @GetMapping("/doctype/download")
    public void doctypeReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename=Jenis Dokumen.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<DocumentTypeDto> listOfDocType = documentTypeService.findAll();
    	JenisDokumenReport generator = new JenisDokumenReport(listOfDocType);
    	generator.generateExcelFile(response);
    }
    
    @GetMapping("/pinjamantype/download")
    public void pinjamanTypeReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename=Jenis Pinjaman.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<PinjamanTypeDto> listOfPinjamanType = pinjamanTypeService.findAll();
    	JenisPinjamanReport generator = new JenisPinjamanReport(listOfPinjamanType);
    	generator.generateExcelFile(response);
    }
    
    @GetMapping("/segmen/download")
    public void segmenReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename=Segmen.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<SegmenDto> listOfSegmen = segmenService.findAll();
    	SegmenReport generator = new SegmenReport(listOfSegmen);
    	generator.generateExcelFile(response);
    }
    
    @GetMapping("/wilayah/download")
    public void wilayahReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename=Wilayah.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<WilayahDto> listOfWilayah= wilayahService.findAll();
    	WilayahReport generator = new WilayahReport(listOfWilayah);
    	generator.generateExcelFile(response);
    }
    
    @GetMapping("/notaris/download")
    public void notarisReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename=Notaris.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<NotarisDto> listOfNotaris= notarisService.findAll();
    	NotarisReport generator = new NotarisReport(listOfNotaris);
    	generator.generateExcelFile(response);
    }
    
    @GetMapping("/kurir/download")
    public void kurirReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename=Kurir.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<KurirDto> listOfKurir= kurirService.findAll();
    	KurirReport generator = new KurirReport(listOfKurir);
    	generator.generateExcelFile(response);
    }
    
    @GetMapping("/region/download")
    public void regionReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename= Data Region.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<RegionDto> listOfRegion= regionService.findAll();
    	RegionReport generator = new RegionReport(listOfRegion);
    	generator.generateExcelFile(response);
    }
    
    @GetMapping("/area/download")
    public void areaReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename= Data Area.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<AreaDto> listOfArea= areaService.findAll();
    	AreaReport generator = new AreaReport(listOfArea);
    	generator.generateExcelFile(response);
    }
    
    @GetMapping("/cabang/download")
    public void cabangReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename= Data Cabang.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<BranchDto> listOfBranch= branchService.findAll();
    	BranchReport generator = new BranchReport(listOfBranch);
    	generator.generateExcelFile(response);
    }
    
    @GetMapping("/storage/download")
    public void storageReport(HttpServletResponse response) throws IOException {
    	response.setContentType("application/octet-stream");
    	
    	String headerKey = "Content-Disposition";
    	String headerValue = "attachment; filename= Lemari & Rak.xlsx";
    	response.setHeader(headerKey, headerValue);
    	
    	List<StorageDto> listOfStorage= storageService.findAll();
    	StorageReport generator = new StorageReport(listOfStorage);
    	generator.generateExcelFile(response);
    }
}
